import 'package:flutter/material.dart';

class FirstSetting extends StatefulWidget {
  const FirstSetting({super.key});

  @override
  State<FirstSetting> createState() => _FirstSettingState();
}

class _FirstSettingState extends State<FirstSetting> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
